app.controller('productsCtrl', function($scope) {
    $scope.services = [
        { "title": "Antalya", "time": "17:40", "price": 200, "image": "images/antalya.jpg" },
        { "title": "Dublin", "time": "5:50", "price": 350, "image": "images/dublin.jpg" },
        { "title": "Frankfurt", "time": "12:45", "price": 200, "image": "images/frankfurt.jpg" },
        { "title": "Moscow", "time": "11:50", "price": 300, "image": "images/moskow.jpg" },
        { "title": "Istambul", "time": "17:50", "price": 150, "image": "images/stambul.jpg" },
        { "title": "Tel Aviv", "time": "2:10", "price": 450, "image": "images/tel-aviv.jpg" },
        { "title": "Verona", "time": "20:45", "price": 250, "image": "images/verona.jpg" },
        { "title": "Roma", "time": "19:10",  "price": 300, "image": "images/roma.jpg" },
        { "title": "London", "time": "14:20", "price": 800, "image": "images/london.jpg" },
          ];

    $scope.inputLogin = "";
    $scope.inputPass = "";

    $scope.login = "admin";
    $scope.password = "password";
    $scope.isSignIn = false;
    $scope.editing = false;


    $scope.signIn = function() {
        if ($scope.inputLogin === $scope.login) {
            if ($scope.inputPass == $scope.password) {
                $scope.isSignIn = true;
                document.getElementById('myModal').style.display = "none"
            }
        }
    };

    $scope.removeProduct = function(itemTitle) {
        const index = $scope.services.findIndex(x => x.title === itemTitle);

        $scope.services.splice(index, 1);

        console.log(index);
    }
	


    $scope.addNewService = function() {
        newService = {
            title: "Unknown",
            price: 0,
            image: "images/logo.png"
        }

        $scope.services.push(newService);
    }


    $scope.orderByMe = function(item) {
        $scope.myOrderBy = item;
        $scope.reverseOrder();
    }

    $scope.myReverseBy = false;
    $scope.reverseOrder = function() {
        $scope.myReverseBy = !($scope.myReverseBy);
    }


});