app.controller('questionCtrl', function($scope) {
    $scope.typeOfQuestions = [
        "Нужен ли тест на COVID-19?",
        "Кормят ли в самолёте?",
        "Какие размеры ручной клади?",
        "Какую сумму денег нужно декларировать?",
        "Другой вопрос"
    ];
});