<?php

namespace ContainerFqNefxZ;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder2b3fa = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializereddc9 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties02b48 = [
        
    ];

    public function getConnection()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getConnection', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getMetadataFactory', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getExpressionBuilder', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'beginTransaction', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->beginTransaction();
    }

    public function getCache()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getCache', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getCache();
    }

    public function transactional($func)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'transactional', array('func' => $func), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'wrapInTransaction', array('func' => $func), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'commit', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->commit();
    }

    public function rollback()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'rollback', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getClassMetadata', array('className' => $className), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'createQuery', array('dql' => $dql), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'createNamedQuery', array('name' => $name), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'createQueryBuilder', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'flush', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'clear', array('entityName' => $entityName), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->clear($entityName);
    }

    public function close()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'close', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->close();
    }

    public function persist($entity)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'persist', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'remove', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'refresh', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'detach', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'merge', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getRepository', array('entityName' => $entityName), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'contains', array('entity' => $entity), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getEventManager', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getConfiguration', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'isOpen', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getUnitOfWork', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getProxyFactory', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'initializeObject', array('obj' => $obj), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'getFilters', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'isFiltersStateClean', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'hasFilters', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return $this->valueHolder2b3fa->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializereddc9 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder2b3fa) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder2b3fa = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder2b3fa->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, '__get', ['name' => $name], $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        if (isset(self::$publicProperties02b48[$name])) {
            return $this->valueHolder2b3fa->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b3fa;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder2b3fa;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, '__set', array('name' => $name, 'value' => $value), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b3fa;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder2b3fa;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, '__isset', array('name' => $name), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b3fa;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder2b3fa;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, '__unset', array('name' => $name), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b3fa;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder2b3fa;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, '__clone', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        $this->valueHolder2b3fa = clone $this->valueHolder2b3fa;
    }

    public function __sleep()
    {
        $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, '__sleep', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;

        return array('valueHolder2b3fa');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializereddc9 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializereddc9;
    }

    public function initializeProxy() : bool
    {
        return $this->initializereddc9 && ($this->initializereddc9->__invoke($valueHolder2b3fa, $this, 'initializeProxy', array(), $this->initializereddc9) || 1) && $this->valueHolder2b3fa = $valueHolder2b3fa;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder2b3fa;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder2b3fa;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
