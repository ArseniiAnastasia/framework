<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/list' => [[['_route' => 'product_list', '_controller' => 'App\\Controller\\ProductController::showAll'], null, null, null, false, false, null]],
        '/new' => [[['_route' => 'new_flight', '_controller' => 'App\\Controller\\ProductController::newAction'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/product/(?'
                    .'|edit/([^/]++)(*:32)'
                    .'|delete/([^/]++)(*:54)'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:90)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        32 => [[['_route' => 'product_edit', '_controller' => 'App\\Controller\\ProductController::update'], ['id'], null, null, false, true, null]],
        54 => [[['_route' => 'product_delete', '_controller' => 'App\\Controller\\ProductController::delete'], ['id'], null, null, false, true, null]],
        90 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
