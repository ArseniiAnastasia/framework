<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request; 
use Symfony\Component\Form\Extension\Core\Type\TextType; 
use Symfony\Component\Form\Extension\Core\Type\SubmitType; 

use App\Entity\Category;
use App\Entity\Product;
use Doctrine\ORM\EntityManagerInterface;


class ProductController extends AbstractController
{

/**
 * @Route("/list", name="product_list")
 */
public function showAll()
{
    $products  = $this->getDoctrine()->getRepository(Product::class)->findAll();

    return $this->render('product/list.html.twig',[
        'products' => $products,
    ]);
}

/** 
   * @Route("/new", name="new_flight") 
*/ 

public function newAction(Request $request) { 
    $stud = new Product();
    $category = new Category();
    $category->setDestination('Flights');

       $form = $this->createFormBuilder($stud) 
          ->add('destination', TextType::class) 
          ->add('time', TextType::class) 
          ->add('price', TextType::class) 
          ->add('save', SubmitType::class, array('label' => 'Submit')) 
          ->getForm(); 
          
        $form->handleRequest($request);  
   
          if ($form->isSubmitted() && $form->isValid()) { 

            $stud->setCategory($category);
             $stud = $form->getData(); 
             $doct = $this->getDoctrine()->getManager(); 
             
             // tells Doctrine you want to save the Product 
             $doct->persist($stud);  
             $doct->persist($category);
             
             //executes the queries (i.e. the INSERT query) 
             $doct->flush();  
             
             return $this->redirectToRoute('product_list'); 
          } else {  
    return $this->render('product/new.html.twig', array('form' => $form->createView(),)); 
 } 
}
 
/**
 * @Route("/product/edit/{id}", name="product_edit")
 */
public function update($id, Request $request)
{
    $doct = $this->getDoctrine()->getManager(); 
    $bk = $doct->getRepository(Product::class)->find($id);

    if (!$bk) {
        throw $this->createNotFoundException(
            'No flight found for id '.$id
        );
    }

    $form = $this->createFormBuilder($bk) 

    ->add('destination', TextType::class) 
    ->add('time', TextType::class) 
    ->add('price', TextType::class) 
    ->add('save', SubmitType::class, array('label' => 'Submit')) 
    ->getForm(); 

    $form->handleRequest($request);  


    if ($form->isSubmitted() && $form->isValid()) { 
        $stud = $form->getData(); 
        $doct = $this->getDoctrine()->getManager();  

        // tells Doctrine you want to save the Product 
      $doct->persist($stud);  

      //executes the queries (i.e. the INSERT query) 
      $doct->flush(); 
      return $this->redirectToRoute('product_list'); 
   } else {
    return $this->render('product/new.html.twig', array('form' => $form->createView(),)); 
}
}
/**
 * @Route("/product/delete/{id}", name="product_delete")
 */
public function delete($id){
    $product = $this->getDoctrine()->getRepository(Product::class)->find($id);
    $entityManager = $this->getDoctrine()->getManager();


    if (!$product) { 
        throw $this->createNotFoundException('No flight found for id '.$id); 
     } 


    //remove the product with id = $id
    $entityManager -> remove($product);
    $entityManager -> flush();

    return $this->redirectToRoute('product_list'); 
}

}
